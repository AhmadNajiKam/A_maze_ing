"""Find a shortest maze route using breadth-first search."""

from collections import deque

from .directions import Cell
from .grid import MazeGrid


class BFS:
    """Solve a wall-bit grid using (row, column) endpoint coordinates."""

    def __init__(
            self,
            maze: list[list[int]],
            entry: Cell,
            exit: Cell,) -> None:
        """Store the maze and the endpoints to be connected."""
        self._grid = MazeGrid(maze)
        if not self._grid.contains(entry) or not self._grid.contains(exit):
            raise ValueError("Solver endpoints must be inside the maze")
        self.entry = entry
        self.exit = exit

    def solve(self) -> str:
        """Return shortest N/E/S/W directions or raise if no route exists."""
        queue = deque([self.entry])
        visited = {self.entry}
        parent: dict[Cell, tuple[Cell, str]] = {}

        while queue:
            current = queue.popleft()
            if current == self.exit:
                break
            for cell, direction in self._grid.reachable_neighbors(current):
                if cell not in visited:
                    visited.add(cell)
                    parent[cell] = current, direction
                    queue.append(cell)

        if self.exit not in visited:
            raise ValueError("No path found from entry to exit")

        path = []
        current = self.exit

        while current != self.entry:
            current, direction = parent[current]
            path.append(direction)

        path.reverse()

        return ''.join(path)
